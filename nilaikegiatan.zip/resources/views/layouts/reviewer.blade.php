
<li class="nav-link">
    <a href="/admin/dashboard" class="nav-link"><i class="fas fa-home"></i>  Home</a>
  </li>
  <li class="nav-link">
    <a href="/reviewer" class="nav-link"><i class="fas fa-book"></i>  List Proposal</a>
  </li>