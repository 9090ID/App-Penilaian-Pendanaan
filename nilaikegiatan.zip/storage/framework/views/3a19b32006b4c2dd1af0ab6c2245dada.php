

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 px-4">
            <div class="content">
                <h1>Daftar Item Penilaian</h1>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('penilaian.tambahNilai')); ?>" class="btn btn-danger mb-4">Tambah Item Penilaian</a>
                    
                <table id="penilaianTable" class="table table-bordered mt-3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kategori</th>
                            <th>Kegiatan</th>
                            <th>Item</th>
                            <th>Bobot</th>
                            <th>Max Nilai</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($penilaian->id); ?></td>
                                <td><?php echo e($penilaian->kategori->nama_kategori ?? 'Tidak Ada'); ?></td>
                                <td><?php echo e($penilaian->kegiatan->nama_kegiatan); ?></td>
                                <td><?php echo e($penilaian->item); ?></td>
                                <td><?php echo e($penilaian->bobot); ?></td>
                                <td><?php echo e($penilaian->max_nilai); ?></td>
                                <td>
                                    <a href="<?php echo e(route('penilaian.edit', [$penilaian->kategori_id, $penilaian->kegiatan_id])); ?>" class="btn btn-sm btn-warning">Edit</a>

                                    <form action="<?php echo e(route('penilaian.destroy', $penilaian->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini?')"><i class="fas fa-trash"></i> Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    // Inisialisasi DataTables untuk tabel dengan id 'rekapTable'
    $(document).ready(function() {
        $('#penilaianTable').DataTable();
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBSITE-DOMAIN-HOST\GITHUB\nilaikegiatan\resources\views/admin/penilaian/index.blade.php ENDPATH**/ ?>