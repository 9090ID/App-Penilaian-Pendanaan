
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('pendaftaran.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="kegiatan_id">Pilih Kegiatan</label>
        <select name="kegiatan_id" id="kegiatan_id" class="form-control" required>
            <option value="">Pilih Kegiatan</option>
            <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_kegiatan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <?php $__currentLoopData = $fieldDefinitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <label for="<?php echo e($field->field_name); ?>"><?php echo e($field->field_label); ?></label>

            <?php if($field->field_type == 'select'): ?>
                <select name="dynamic_fields[<?php echo e($field->field_name); ?>]" id="<?php echo e($field->field_name); ?>" class="form-control">
                    <?php $__currentLoopData = json_decode($field->options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php elseif($field->field_type == 'text'): ?>
                <input type="text" name="dynamic_fields[<?php echo e($field->field_name); ?>]" class="form-control">
            <?php elseif($field->field_type == 'number'): ?>
                <input type="number" name="dynamic_fields[<?php echo e($field->field_name); ?>]" class="form-control">
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button type="submit" class="btn btn-primary">Daftar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBSITE-DOMAIN-HOST\GITHUB\nilaikegiatan\resources\views/pendaftaran/create.blade.php ENDPATH**/ ?>