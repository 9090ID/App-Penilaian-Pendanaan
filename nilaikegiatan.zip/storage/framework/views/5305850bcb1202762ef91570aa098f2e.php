<nav class="col-12 col-md-3 col-lg-2 sidebar d-flex flex-column p-3">
  <?php if(auth()->user()->role === 'admin'): ?>
    <h4 class="text-center">Halaman Admin</h4>
    <?php else: ?>
    <h4 class="text-center">Halaman Reviewer</h4>
    <?php endif; ?>
    
      <?php if(auth()->guard()->check()): ?>
      <?php if(auth()->user()->role === 'admin'): ?>
      <ul class="nav flex-column">
        <?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(auth()->user()->role === 'reviewer'): ?>
        <?php echo $__env->make('layouts.reviewer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <li class="nav-link">
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
        <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out"></i> Logout</a>
      </li>
      <?php endif; ?>
    </ul>
  </nav><?php /**PATH D:\WEBSITE-DOMAIN-HOST\GITHUB\nilaikegiatan\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>