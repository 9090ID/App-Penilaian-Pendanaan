<li class="nav-item">
    <a href="/admin/dashboard" class="nav-link"><i class="fas fa-home"></i>  Home</a>
  </li>
<li class="nav-item">
  <a href="/users" class="nav-link"><i class="fas fa-users"></i>  Users</a>
</li>
<li class="nav-item">
  <a href="/kegiatan" class="nav-link"><i class="fas fa-file-alt"></i> Nama Kegiatan</a>
</li>

<li class="nav-item">
  <a href="/proposal" class="nav-link"><i class="fas fa-book"></i>  Daftar Proposal</a>
</li>
<li class="nav-item">
  <a href="/penilaian" class="nav-link"><i class="fas fa-check"></i> Rubrik Peniliaan</a>
</li>
<li class="nav-item">
  <a href="/rekap" class="nav-link"><i class="fas fa-list-alt"></i> Rekap Peniliaan</a>
</li>
<?php /**PATH D:\WEBSITE-DOMAIN-HOST\GITHUB\nilaikegiatan\resources\views/layouts/admin.blade.php ENDPATH**/ ?>