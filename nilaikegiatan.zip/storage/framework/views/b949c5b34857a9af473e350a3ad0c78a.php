

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 px-4">
                <div class="content">
                    <h1>Daftar Proposal</h1>
                    <form action="<?php echo e(route('proposal.import')); ?>" method="POST" enctype="multipart/form-data" class="md-4">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="file">Upload File Excel</label>
                            <input type="file" name="file" id="file" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success">Import Excel</button>
                    </form>
                    <br>
                    
                    <hr>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <table id="proposalTable" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kegiatan</th>
                                <th>Kategori</th>
                                <th>Nama Ketua</th>
                                <th>Judul Proposal</th>
                                <th>Dosen Pembimbing</th>
                                <th>Link Proposal</th>
                                <th>Reviewers</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                    </table>


                </div>
            </div>
        </div>
    </div>
    <!-- Modal for Editing Proposal -->
    <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal for Editing Proposal -->
        <div class="modal fade" id="editProposalModal<?php echo e($proposal->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="editProposalModalLabel" aria-hidden="false">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editProposalModalLabel">Edit Proposal</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('proposal.update', $proposal->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="kegiatan_id">Kegiatan</label>
                                <input type="text" class="form-control" id="kegiatan_id"
                                    value="<?php echo e($proposal->kegiatan->nama_kegiatan); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="kategori_id">Kategori</label>
                                <input type="text" class="form-control" id="kategori_id"
                                    value="<?php echo e($proposal->kategori->nama_kategori ?? 'Tidak Ada'); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="nimKetua">NIM Ketua</label>
                                <input type="text" class="form-control" id="nimKetua" name="nimKetua"
                                    value="<?php echo e($proposal->nimKetua); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="judul_proposal">Judul Proposal</label>
                                <input type="text" class="form-control" id="judul_proposal" name="judul_proposal"
                                    value="<?php echo e($proposal->judul_proposal); ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="reviewers">Reviewers</label>
                                <select class="form-control" id="reviewers" name="reviewers[]" multiple required>
                                    <?php $__currentLoopData = $reviewers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reviewer->id); ?>"
                                            <?php echo e(in_array($reviewer->id, $proposal->reviewers->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                                            <?php echo e($reviewer->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Set Reviewer</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
       $(document).ready(function () {
        $('#proposalTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(route('get.datatables')); ?>',
            columns: [
                { data: 'id', name: 'id' },
                { data: 'kegiatan', name: 'kegiatan.nama_kegiatan' },
                { data: 'kategori', name: 'kategori.nama_kategori' },
                { data: 'namaKetua', name: 'namaKetua' },
                { data: 'judul_proposal', name: 'judul_proposal' },
                { data: 'dosenPembimbing', name: 'dosenPembimbing' },
                { data: 'linkproposal', name: 'linkproposal', orderable: false, searchable: false },
                { data: 'reviewers', name: 'reviewers', orderable: false, searchable: false },
                { data: 'aksi', name: 'aksi', orderable: false, searchable: false }
            ]
        });
    });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEBSITE-DOMAIN-HOST\GITHUB\nilaikegiatan\resources\views/proposal/index.blade.php ENDPATH**/ ?>